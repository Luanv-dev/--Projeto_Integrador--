﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MEtechnology.Migrations
{
    public partial class mudanca : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "imagem",
                table: "produtos",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "review",
                table: "produtos",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "imagem",
                table: "produtos");

            migrationBuilder.DropColumn(
                name: "review",
                table: "produtos");
        }
    }
}
