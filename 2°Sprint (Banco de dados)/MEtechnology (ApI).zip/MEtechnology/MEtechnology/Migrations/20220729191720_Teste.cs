﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MEtechnology.Migrations
{
    public partial class Teste : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_produtos_classeprodutos_ClasseProdutoId",
                table: "produtos");

            migrationBuilder.RenameColumn(
                name: "ClasseProdutoId",
                table: "produtos",
                newName: "ClassedoProdutosId");

            migrationBuilder.RenameIndex(
                name: "IX_produtos_ClasseProdutoId",
                table: "produtos",
                newName: "IX_produtos_ClassedoProdutosId");

            migrationBuilder.AddForeignKey(
                name: "FK_produtos_classeprodutos_ClassedoProdutosId",
                table: "produtos",
                column: "ClassedoProdutosId",
                principalTable: "classeprodutos",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_produtos_classeprodutos_ClassedoProdutosId",
                table: "produtos");

            migrationBuilder.RenameColumn(
                name: "ClassedoProdutosId",
                table: "produtos",
                newName: "ClasseProdutoId");

            migrationBuilder.RenameIndex(
                name: "IX_produtos_ClassedoProdutosId",
                table: "produtos",
                newName: "IX_produtos_ClasseProdutoId");

            migrationBuilder.AddForeignKey(
                name: "FK_produtos_classeprodutos_ClasseProdutoId",
                table: "produtos",
                column: "ClasseProdutoId",
                principalTable: "classeprodutos",
                principalColumn: "Id");
        }
    }
}
