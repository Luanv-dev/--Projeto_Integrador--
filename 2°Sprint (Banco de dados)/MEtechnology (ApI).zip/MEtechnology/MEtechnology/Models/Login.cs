﻿namespace MEtechnology.Models
{
    public class Login
    {
        public int Id { get; set; }
        public string usuario { get; set; }
        public string senha { get; set; }
    }
}
