﻿using System.Text.Json.Serialization;

namespace MEtechnology.Models
{
    public class Produtos
    {
        
        public int Id { get; set; }

        public string nome { get; set; } // celular m31
        public string descricao { get; set; }
        public decimal preco { get; set; }

        public string review { get; set; }

        public string imagem { get; set; }
        public ClasseProdutos? ClassedoProdutos { get; set; }
        
    }
}
