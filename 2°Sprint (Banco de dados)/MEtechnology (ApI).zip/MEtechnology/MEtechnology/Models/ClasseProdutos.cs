﻿using System.Text.Json.Serialization;

namespace MEtechnology.Models
{
    public class ClasseProdutos
    {
        
        public int Id { get; set; }
        public string classe { get; set; }

        [JsonIgnore]
        public List<Produtos>? Produtos { get; set; } = new List<Produtos>();
    }
}
